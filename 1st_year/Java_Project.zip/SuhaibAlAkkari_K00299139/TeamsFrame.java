// Name: Suhaib Al Akkari
// Date: 28/04/2024
// TeamsFrame

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TeamsFrame extends JFrame
{	
	// teams tab variables
	private JTextArea teamsTxt; // teams textarea
	private JLabel addTeamLbl; // add team label
	private JLabel addNumOfPlayersLbl; // number of players label
	private JLabel addPlayerLbl; // add player label
	private JLabel removePlayerLbl; // remove player label
	private JLabel removeTeamLbl; // remove team label
	private JLabel teamsImgLbl; // image label
	private JTextField addTeamTf; // add team textfield
	private JTextField addNumOfPlayersTf; // add number of players textfield
	private JTextField addPlayerTf; // add player textfield
	private JTextField removePlayerTf; // remove player textfield
	private JTextField removeTeamTf; // remove team textfield
	private JButton addTeamBtn; // add team button
	private JButton addPlayerBtn; // add player button
	private JButton removePlayerBtn; // remove player button
	private JButton removeTeamBtn; // remove team button
	
	// matches tab variables
	private JTextArea matchTxt; // matches textarea
	private JLabel team1Lbl; // team1 label
	private JLabel team2Lbl; // team2 label
	private JLabel rounds1Lbl; // team1 rounds label
	private JLabel rounds2Lbl; // team2 rounds label
	private JLabel winnerLbl; // final winner label
	private JLabel matchesImgLbl; // image label
	private JTextField team1Tf; // team1 textfield
	private JTextField team2Tf; // team2 textfield
	private JTextField rounds1Tf; // team1 rounds textfield
	private JTextField rounds2Tf; // team2 rounds textfield
	private JButton matchBtn; // add match button
	private ArrayList<String> lostTeams = new ArrayList<>(); // disqualified teams arraylist
	
	// shop tab variables
	private JLabel totalPriceLbl; // total price label
	private JLabel item1Lbl; // item1 image label
	private JLabel item2Lbl; // item2 image label
	private JLabel item3Lbl; // item3 image label
	private JLabel item4Lbl; // item4 image label
	private JLabel item5Lbl; // item5 image label
	private JLabel item6Lbl; // item6 image label
	private JLabel price1Lbl; // item1 price label
	private JLabel price2Lbl; // item2 price label
	private JLabel price3Lbl; // item3 price label
	private JLabel price4Lbl; // item4 price label
	private JLabel price5Lbl; // item5 price label
	private JLabel price6Lbl; // item6 price label
	private JLabel voucherLbl; // voucher label
	private JLabel voucherPromoLbl; // voucher promotion label
	private JTextField voucherTf; // voucher textfield
	private JButton voucherBtn; // apply voucher button
	private JButton buy1Btn; // but item1 button
	private JButton buy2Btn; // but item2 button
	private JButton buy3Btn; // but item3 button
	private JButton buy4Btn; // but item4 button
	private JButton buy5Btn; // but item5 button
	private JButton buy6Btn; // but item6 button
	private static final double item1Price = 265.65; // item1 price
	private static final double item2Price = 15.35; // item2 price
	private static final double item3Price = 5.55 ; // item3 price
	private static final double item4Price = 1.50; // item4 price
	private static final double item5Price = 5.58; // item5 price
	private static final double item6Price = 2.45; // item6 price
	private double totalPrice = 0; // total shopping price
	private boolean checkVoucher = true; // to check if the vouched was used

	// info tab variables
	private JLabel info1Lbl; // info label
	private JLabel info2Lbl; // info label
	private JLabel info3Lbl; // info label
	private JLabel info4Lbl; // info label
	private JLabel info5Lbl; // info label
	private JLabel info6Lbl; // info label
	private JLabel info7Lbl; // info label
	private JLabel info8Lbl; // info label
	private JLabel info9Lbl; // info label
	private JLabel info10Lbl; // info label
	private JLabel info11Lbl; // info label
	private JLabel tyLbl; // thank you label
	private JLabel infoCreditLbl; // credit label
	private JLabel infoImgLbl; // image label

	//constant size variables
	private static final int FRAME_WIDTH = 600;
	private static final int FRAME_HEIGHT = 800;
	private static final int TEXT_WIDTH = 10;
	private static final int AREA_ROWS = 10;
	private static final int AREA_COLOMNS = 45;

	//creating a new Teams object
	Teams t = new Teams();

	//creating TeamFrame
	public TeamsFrame()
	{
		createComponents();
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
	} // end of TeamFrame

	//add team actionlistener
	public class AddTeamListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			String intCheck = addNumOfPlayersTf.getText(); // to check if the string can be converted to an int
			Scanner scan = new Scanner(intCheck); // scanner for intCheck

			if(addTeamTf.getText().isEmpty()) // checking if textfield is empty
			{
				JOptionPane.showMessageDialog(null, "Please Enter The Team's Name", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else if(addNumOfPlayersTf.getText().isEmpty()) // checking if textfield is empty
			{
				JOptionPane.showMessageDialog(null, "Please Enter The Number of Players", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else if(!scan.hasNextInt()) // checking if the string cannot be converted to int
			{
				JOptionPane.showMessageDialog(null, "Please Enter a Number Between 5 and 10", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				String team = addTeamTf.getText(); // getting the team name
				int nop = Integer.parseInt(addNumOfPlayersTf.getText()); // geting the number of players

				if(t.containsTeams(team)) // checking of the team name already exists
				{
					JOptionPane.showMessageDialog(null, "Team Already Exists", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
				else if(nop > 10 || nop < 5) // checking that if the number of players isnt suitable
				{
					JOptionPane.showMessageDialog(null, "Teams Must Have 5-10 Players", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					t.addTeam(team); // adding the new team to the arraylist
					t.addPlayersNum(nop); // adding the number of players to the arraylist
					teamsTxt.setText(null); // emptying the text area
					teamsTxt.append(t.toString()); // reprinting the arraylist into the textarea with the new info
				}
			}
		}
	} // end of add team actionlistener

	// remove team actionlistener
	public class RemoveTeamListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			if(removeTeamTf.getText().isEmpty()) // checking if textfield is empty
			{
				JOptionPane.showMessageDialog(null, "Please Enter The Team's Name", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				String team = removeTeamTf.getText(); // getting the team name

				if(t.containsTeams(team)) //checking of the team name exists in the arralist
				{
					t.removePlayersNum(t.indexOfTeams(team)); // removing the number of players for that team
					t.removeTeams(t.indexOfTeams(team)); // removing the team name

					teamsTxt.setText(null); // emptying the text area
					teamsTxt.append(t.toString()); // reprinting the arraylist into the textarea with the new info
				}
				else // if the team name does not exist in the arraylist
				{
					JOptionPane.showMessageDialog(null, "Team Does not Exist", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		}
	} // end of remove team actionlistener

	// add player actionlistener
	public class AddPlayerListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			if(addPlayerTf.getText().isEmpty()) // checking if textfield is empty
			{
				JOptionPane.showMessageDialog(null, "Please Enter The Team's Name", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				String team = addPlayerTf.getText(); // getting the team name

				if(t.containsTeams(team) && t.getPlayersNum(t.indexOfTeams(team)) < 10) // checking if the team exists in the arraylist and the number of players is less than 10
				{
					t.setPlayersNum(t.indexOfTeams(team), t.getPlayersNum(t.indexOfTeams(team)) + 1); // adding a player

					teamsTxt.setText(null); // emptying the text area
					teamsTxt.append(t.toString()); // reprinting the arraylist into the textarea with the new info
				}
				else if(!t.containsTeams(team)) // if the team name does not exist in the arraylist 
				{
					JOptionPane.showMessageDialog(null, "Team Does not Exist", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
				else // if the a team already has the max amount of players (10)
				{
					JOptionPane.showMessageDialog(null, "Too Many Players", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		}
	} // end of add player actionlistener

	// remove player action listener
	public class RemovePlayerListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			if(removePlayerTf.getText().isEmpty()) // checking if textfield is empty
			{
				JOptionPane.showMessageDialog(null, "Please Enter The Team's Name", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				String team = removePlayerTf.getText(); // getting the team name

				if(t.containsTeams(team) && t.getPlayersNum(t.indexOfTeams(team)) > 5) // checking if the team exists in the arraylist and the number of players is more than 5
				{
					t.setPlayersNum(t.indexOfTeams(team), t.getPlayersNum(t.indexOfTeams(team)) - 1); // removing a player

					teamsTxt.setText(null); // emptying the text area
					teamsTxt.append(t.toString()); // reprinting the arraylist into the textarea with the new info
				}
				else if(!t.containsTeams(team)) // if the team name does not exist in the arraylist 
				{
					JOptionPane.showMessageDialog(null, "Team Does not Exist", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
				else // if the a team already has the min amount of players (5)
				{
					JOptionPane.showMessageDialog(null, "Cannot Remove More Players", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		}
	} // end of remove player action listener

	// add match actionlistener
	public class AddMatchListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			String intCheck1 = rounds1Tf.getText(); // to check if the string can be converted to an int
			String intCheck2 = rounds2Tf.getText(); // to check if the string can be converted to an int
			Scanner scan1 = new Scanner(intCheck1); // scanner for intCheck1
			Scanner scan2 = new Scanner(intCheck2); // scanner for intCheck2

			if(team1Tf.getText().isEmpty() || team2Tf.getText().isEmpty()) // checking if textfield is empty
			{
				JOptionPane.showMessageDialog(null, "Please Enter The Teams' Names", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else if(rounds1Tf.getText().isEmpty() || rounds2Tf.getText().isEmpty()) // checking if textfield is empty
			{
				JOptionPane.showMessageDialog(null, "Please Enter The Teams' Rounds", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else if(!scan1.hasNextInt() || !scan2.hasNextInt()) // checking if the strings cannot be converted to int
			{
				JOptionPane.showMessageDialog(null, "Please Enter Numbers In Teams' Rounds Fields", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				String team1 = team1Tf.getText(); // getting the team1 name
				String team2 = team2Tf.getText(); // getting the team2 name
				int rounds1 = Integer.parseInt(rounds1Tf.getText()); // gettin the team1 rounds
				int rounds2 = Integer.parseInt(rounds2Tf.getText()); // gettin the team2 rounds

				if(!t.containsTeams(team1) || !t.containsTeams(team2) || team1.equals(team2)) // checking if the teams do not exist in the array lost or if team1 and team2 are the same
				{
					JOptionPane.showMessageDialog(null, "Invalid Teams", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
				else if(lostTeams.contains(team1)) // checking if team1 has already been disqualified
				{
					JOptionPane.showMessageDialog(null, team1 + " Has Already Lost", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
				else if(lostTeams.contains(team2)) // checking if team2 has already been disqualified
				{
					JOptionPane.showMessageDialog(null, team2 + " Has Already Lost", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}
				else if((rounds1 == 13 || ((rounds1 - 13) % 3 == 0 && rounds2 >= rounds1 - 4 )) && rounds2 < rounds1 - 1) // validating rounds1 input (please check the document for more info)
				{
					matchTxt.append(team1 + " VS " + team2 + " | Score: " + rounds1 + " : " + rounds2 + " | Winner: " + team1 + "\n"); // adding the match info to the textarea
					lostTeams.add(team2); // adding the losing team to the disqualified teams arraylist
				}
				else if((rounds2 == 13 || ((rounds2 - 13) % 3 == 0 && rounds1 >= rounds2 - 4 )) && rounds1 < rounds2 - 1) // validating rounds2 input (please check the document for more info)
				{
					matchTxt.append(team1 + " VS " + team2 + " | Score: " + rounds1 + " : " + rounds2 + " | Winner: " + team2 + "\n"); // adding the match info to the textarea
					lostTeams.add(team1); // adding the losing team to the disqualified teams arraylist
				}
				else // if the rounds input is not valid
				{
					JOptionPane.showMessageDialog(null, "Invalid Rounds", "Error!", JOptionPane.INFORMATION_MESSAGE);
				}

				// checking the final winner
				if(lostTeams.size() == t.sizeTeams() - 1)
				{
					if(rounds1 > rounds2)
					{
						winnerLbl.setText("The Winner Is " + team1);
					}
					else
					{
						winnerLbl.setText("The Winner Is " + team2);
					}
				}
			}
		}
	} // end of add match actionlistener

	// buy item actionlisteners
	public class BuyItem1Listener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			totalPrice += item1Price; // adding the item value to the total price
			totalPrice = Math.round(totalPrice * 100) / 100.0; // setting total price to 2 decimals 
			totalPriceLbl.setText("Total Price: " + totalPrice + " $"); // adding the item value to the total price label
		}
	}

	public class BuyItem2Listener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			totalPrice += item2Price; // adding the item value to the total price
			totalPrice = Math.round(totalPrice * 100) / 100.0; // setting total price to 2 decimals 
			totalPriceLbl.setText("Total Price: " + totalPrice + " $"); // adding the item value to the total price label
		}
	}

	public class BuyItem3Listener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			totalPrice += item3Price; // adding the item value to the total price
			totalPrice = Math.round(totalPrice * 100) / 100.0; // setting total price to 2 decimals 
			totalPriceLbl.setText("Total Price: " + totalPrice + " $"); // adding the item value to the total price label
		}
	}

	public class BuyItem4Listener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			totalPrice += item4Price; // adding the item value to the total price
			totalPrice = Math.round(totalPrice * 100) / 100.0; // setting total price to 2 decimals 
			totalPriceLbl.setText("Total Price: " + totalPrice + " $"); // adding the item value to the total price label
		}
	}

	public class BuyItem5Listener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			totalPrice += item5Price; // adding the item value to the total price
			totalPrice = Math.round(totalPrice * 100) / 100.0; // setting total price to 2 decimals 
			totalPriceLbl.setText("Total Price: " + totalPrice + " $"); // adding the item value to the total price label
		}
	}

	public class BuyItem6Listener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			totalPrice += item6Price; // adding the item value to the total price
			totalPrice = Math.round(totalPrice * 100) / 100.0; // setting total price to 2 decimals 
			totalPriceLbl.setText("Total Price: " + totalPrice + " $"); // adding the item value to the total price label
		}
	} // end of buy item actionlisteners

	// apply voucher actionlistener
	public class ApplyVoucherListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			if(voucherTf.getText().isEmpty()) // checking if textfield is empty
			{
				JOptionPane.showMessageDialog(null, "Please Enter The Voucher", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else if(voucherTf.getText().equals("CS2") && checkVoucher) // cheching if the input matches the right voucher and that it has not been used before
			{
				totalPrice = totalPrice * 0.9; // changing the total price
				totalPrice = Math.round(totalPrice * 100) / 100.0; // setting total price to 2 decimals 
				totalPriceLbl.setText("Total Price: " + totalPrice + " $"); // changing the total price label
				checkVoucher = false; // setting the voucher to 'used'
			}
			else if(!checkVoucher) // if the voucher was already used
			{
				JOptionPane.showMessageDialog(null, "The Voucher Has Already Been Used", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
			else // if the voucher is invalid
			{
				JOptionPane.showMessageDialog(null, "Invalid Voucher", "Error!", JOptionPane.INFORMATION_MESSAGE);
			}
		}
	} // end of apply voucher actionlistener

	private void createComponents()
	{
		// teams tab components
		teamsTxt = new JTextArea(AREA_ROWS, AREA_COLOMNS);
		teamsTxt.setLocation(20,20);
		teamsTxt.append(t.toString());
		JScrollPane teamsScroll = new JScrollPane(teamsTxt);

		addTeamLbl = new JLabel("Team Name");
		addTeamTf = new JTextField(TEXT_WIDTH);
		addNumOfPlayersLbl = new JLabel("No of Players");
		addNumOfPlayersTf = new JTextField(TEXT_WIDTH);
		addTeamBtn = new JButton("Add Team");
		AddTeamListener addTeamL = new AddTeamListener();
		addTeamBtn.addActionListener(addTeamL);

		addPlayerLbl = new JLabel("Team Name");
		addPlayerTf = new JTextField(TEXT_WIDTH);
		addPlayerBtn = new JButton("    Add Player    ");
		AddPlayerListener addPlayerL = new AddPlayerListener();
		addPlayerBtn.addActionListener(addPlayerL);

		removePlayerLbl = new JLabel("Team Name");
		removePlayerTf = new JTextField(TEXT_WIDTH);
		removePlayerBtn = new JButton("Remove Player");
		RemovePlayerListener removePlayerL = new RemovePlayerListener();
		removePlayerBtn.addActionListener(removePlayerL);

		removeTeamLbl = new JLabel("Team Name");
		removeTeamTf = new JTextField(TEXT_WIDTH);
		removeTeamBtn = new JButton("Remove Team  ");
		RemoveTeamListener removeTeamL = new RemoveTeamListener();
		removeTeamBtn.addActionListener(removeTeamL);

		teamsImgLbl = new JLabel();
		teamsImgLbl.setIcon(new ImageIcon("images/tAgent.png"));

		// teams tab panels and style
		JPanel teams = new JPanel(); // main panel
		teams.setBorder(BorderFactory.createLineBorder(Color.blue)); // setting a border
		teams.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));
		// sub-panels
		JPanel teams1 = new JPanel();
		teams1.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
		JPanel teams2 = new JPanel();
		teams2.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
		JPanel teams3 = new JPanel();
		teams3.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
		JPanel teams4 = new JPanel();
		teams4.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
		JPanel teams5 = new JPanel();
		teams5.setLayout(new FlowLayout(FlowLayout.CENTER, 200, 20));
		
		// adding teams tab component to its panels
		teams.add(teamsScroll);
		teams1.add(addTeamLbl);
		teams1.add(addTeamTf);
		teams1.add(addNumOfPlayersLbl);
		teams1.add(addNumOfPlayersTf);
		teams1.add(addTeamBtn);
		teams2.add(addPlayerLbl);
		teams2.add(addPlayerTf);
		teams2.add(addPlayerBtn);
		teams3.add(removePlayerLbl);
		teams3.add(removePlayerTf);
		teams3.add(removePlayerBtn);
		teams4.add(removeTeamLbl);
		teams4.add(removeTeamTf);
		teams4.add(removeTeamBtn);
		teams5.add(teamsImgLbl);
		teams.add(teams1);
		teams.add(teams2);
		teams.add(teams3);
		teams.add(teams4);
		teams.add(teams5);

		// matches tab components
		matchTxt = new JTextArea(AREA_ROWS, AREA_COLOMNS);
		JScrollPane matchesScroll = new JScrollPane(matchTxt);

		team1Lbl = new JLabel("First Team Name   ");
		team1Tf = new JTextField(TEXT_WIDTH);
		team2Lbl = new JLabel("Second Team Name   ");
		team2Tf = new JTextField(TEXT_WIDTH);
		rounds1Lbl = new JLabel("First Team Rounds");
		rounds1Tf = new JTextField(TEXT_WIDTH);
		rounds2Lbl = new JLabel("Second Team Rounds");
		rounds2Tf = new JTextField(TEXT_WIDTH);
		winnerLbl = new JLabel("");

		matchBtn = new JButton("Add Match");
		AddMatchListener addMatchL = new AddMatchListener();
		matchBtn.addActionListener(addMatchL);

		matchesImgLbl = new JLabel();
		matchesImgLbl.setIcon(new ImageIcon("images/ctAgent.png"));

		// matches tab panels and style
		JPanel matches = new JPanel(); // main panel
		matches.setBorder(BorderFactory.createLineBorder(Color.blue)); // setting a border
		matches.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));
		// sub-panels
		JPanel matches1 = new JPanel();
		matches1.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 10));
		JPanel matches2 = new JPanel();
		matches2.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
		JPanel matches3 = new JPanel();
		matches3.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
		JPanel matches4 = new JPanel();
		matches4.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
		JPanel matches5 = new JPanel();
		matches5.setLayout(new FlowLayout(FlowLayout.CENTER, 200, 100));
		
		// adding matches tab component to its panels
		matches1.add(winnerLbl);
		matches2.add(team1Lbl);
		matches2.add(team1Tf);
		matches2.add(team2Lbl);
		matches2.add(team2Tf);
		matches3.add(rounds1Lbl);
		matches3.add(rounds1Tf);
		matches3.add(rounds2Lbl);
		matches3.add(rounds2Tf);
		matches4.add(matchBtn);
		matches5.add(matchesImgLbl);
		matches.add(matches1);
		matches.add(matchesScroll);
		matches.add(matches2);
		matches.add(matches3);
		matches.add(matches4);
		matches.add(matches5);
		
		// shop tab components
		totalPriceLbl = new JLabel("Total Price: " + totalPrice + " $");
		voucherLbl = new JLabel("Voucher");
		voucherTf = new JTextField(TEXT_WIDTH);
		voucherPromoLbl = new JLabel("Use Code 'CS2' For 10% Off");

		item1Lbl = new JLabel();
		item1Lbl.setIcon(new ImageIcon("images/ShadowDaggers_Doppler.png"));
		item2Lbl = new JLabel();
		item2Lbl.setIcon(new ImageIcon("images/Glock-18_BulletQueen.png"));
		item3Lbl = new JLabel();
		item3Lbl.setIcon(new ImageIcon("images/P250_Visions.png"));
		item4Lbl = new JLabel();
		item4Lbl.setIcon(new ImageIcon("images/CZ75-Auto_Tacticat.png"));
		item5Lbl = new JLabel();
		item5Lbl.setIcon(new ImageIcon("images/P2000_Scorpion.png"));
		item6Lbl = new JLabel();
		item6Lbl.setIcon(new ImageIcon("images/Five-SeveN_Nightshade.png"));

		price1Lbl = new JLabel(item1Price + " $");
		price2Lbl = new JLabel(item2Price + " $");
		price3Lbl = new JLabel(item3Price + " $");
		price4Lbl = new JLabel(item4Price + " $");
		price5Lbl = new JLabel(item5Price + " $");
		price6Lbl = new JLabel(item6Price + " $");

		buy1Btn = new JButton("Buy");
		BuyItem1Listener buyItemL1 = new BuyItem1Listener();
		buy1Btn.addActionListener(buyItemL1);
		buy2Btn = new JButton("Buy");
		BuyItem2Listener buyItemL2 = new BuyItem2Listener();
		buy2Btn.addActionListener(buyItemL2);
		buy3Btn = new JButton("Buy");
		BuyItem3Listener buyItemL3 = new BuyItem3Listener();
		buy3Btn.addActionListener(buyItemL3);
		buy4Btn = new JButton("Buy");
		BuyItem4Listener buyItemL4 = new BuyItem4Listener();
		buy4Btn.addActionListener(buyItemL4);
		buy5Btn = new JButton("Buy");
		BuyItem5Listener buyItemL5 = new BuyItem5Listener();
		buy5Btn.addActionListener(buyItemL5);
		buy6Btn = new JButton("Buy");
		BuyItem6Listener buyItemL6 = new BuyItem6Listener();
		buy6Btn.addActionListener(buyItemL6);
		voucherBtn = new JButton("Apply Voucher");
		ApplyVoucherListener applyVoucherL = new ApplyVoucherListener();
		voucherBtn.addActionListener(applyVoucherL);

		// shop tab panels and style
		JPanel shop = new JPanel(); // main panel
		shop.setBorder(BorderFactory.createLineBorder(Color.blue)); // setting a border
		shop.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 5));
		// sub-panels
		JPanel shop1 = new JPanel();
		shop1.setLayout(new FlowLayout(FlowLayout.CENTER, 100, 4));
		JPanel shop2 = new JPanel();
		shop2.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 4));
		JPanel shop3 = new JPanel();
		shop3.setLayout(new FlowLayout(FlowLayout.CENTER, 80, 4));
		JPanel shop4 = new JPanel();
		shop4.setLayout(new FlowLayout(FlowLayout.CENTER, 200, 4));
		JPanel shop5 = new JPanel();
		shop5.setLayout(new FlowLayout(FlowLayout.CENTER, 190, 4));
		JPanel shop6 = new JPanel();
		shop6.setLayout(new FlowLayout(FlowLayout.CENTER, 80, 4));
		JPanel shop7 = new JPanel();
		shop7.setLayout(new FlowLayout(FlowLayout.CENTER, 210, 4));
		JPanel shop8 = new JPanel();
		shop8.setLayout(new FlowLayout(FlowLayout.CENTER, 190, 4));
		JPanel shop9 = new JPanel();
		shop9.setLayout(new FlowLayout(FlowLayout.CENTER, 80, 4));
		JPanel shop10 = new JPanel();
		shop10.setLayout(new FlowLayout(FlowLayout.CENTER, 215, 4));
		JPanel shop11 = new JPanel();
		shop11.setLayout(new FlowLayout(FlowLayout.CENTER, 190, 4));
		JPanel shop12 = new JPanel();
		shop12.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 4));

		// adding shop tab component to its panels
		shop1.add(totalPriceLbl);
		shop2.add(voucherLbl);
		shop2.add(voucherTf);
		shop2.add(voucherBtn);
		shop3.add(item1Lbl);
		shop3.add(item2Lbl);
		shop4.add(price1Lbl);
		shop4.add(price2Lbl);
		shop5.add(buy1Btn);
		shop5.add(buy2Btn);
		shop6.add(item3Lbl);
		shop6.add(item4Lbl);
		shop7.add(price3Lbl);
		shop7.add(price4Lbl);
		shop8.add(buy3Btn);
		shop8.add(buy4Btn);
		shop9.add(item5Lbl);
		shop9.add(item6Lbl);
		shop10.add(price5Lbl);
		shop10.add(price6Lbl);
		shop11.add(buy5Btn);
		shop11.add(buy6Btn);
		shop12.add(voucherPromoLbl);
		shop.add(shop1);
		shop.add(shop2);
		shop.add(shop3);
		shop.add(shop4);
		shop.add(shop5);
		shop.add(shop6);
		shop.add(shop7);
		shop.add(shop8);
		shop.add(shop9);
		shop.add(shop10);
		shop.add(shop11);
		shop.add(shop12);
		
		// info tab components
		info1Lbl = new JLabel("* Adding a Team: Enter the team's name and the number of players and click on 'Add Team'.");
		info2Lbl = new JLabel("The team's name must be unique and the number of players must be between 5 and 10.");
		info3Lbl = new JLabel("* Removing a Team: Enter the team's name and click on 'Remove Team'.");
		info4Lbl = new JLabel("* Adding a Player: Enter the team's name and click on 'Add Player'.");
		info5Lbl = new JLabel("You can add more than one player, but you cannot have more than 10 players in a team.");
		info6Lbl = new JLabel("* Removing a Player: Enter the team's name and click on 'Remove Player'.");
		info7Lbl = new JLabel("You can remove more than one player, but you cannot have less than 5 players in a team.");
		info8Lbl = new JLabel("* Adding a Match: Enter both teams' names and the rounds for each team and click on 'Add Match'.");
		info9Lbl = new JLabel("The final team standing will be declared the winner.");
		info10Lbl = new JLabel("* Buying Skins: Click on the 'Buy' button under the skin(s) of your choice.");
		info11Lbl = new JLabel("The total price will automatically be calculated for you (Do not forget to use the voucher)");
		tyLbl = new JLabel("Thank you for choosing my app");
		infoCreditLbl = new JLabel("Suhaib Al Akkari");
		infoImgLbl = new JLabel();
		infoImgLbl.setIcon(new ImageIcon("images/CS2.png"));

		// info tab panels and style
		JPanel info = new JPanel(); // main panel
		info.setBorder(BorderFactory.createLineBorder(Color.blue)); // setting a border
		info.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 5));
		// sub-panels
		JPanel info1 = new JPanel();
		info1.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
		JPanel info2 = new JPanel();
		info2.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
		JPanel info3 = new JPanel();
		info3.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
		JPanel info4 = new JPanel();
		info4.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
		JPanel info5 = new JPanel();
		info5.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
		JPanel info6 = new JPanel();
		info6.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
		JPanel info7 = new JPanel();
		info7.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
		JPanel info8 = new JPanel();
		info8.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
		JPanel info9 = new JPanel();
		info9.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
		JPanel info10 = new JPanel();
		info10.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
		JPanel info11 = new JPanel();
		info11.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
		JPanel info12 = new JPanel();
		info12.setLayout(new FlowLayout(FlowLayout.LEFT, 200, 50));
		JPanel info13 = new JPanel();
		info13.setLayout(new FlowLayout(FlowLayout.LEFT, 238, 0));
		JPanel info14 = new JPanel();
		info14.setLayout(new FlowLayout(FlowLayout.LEFT, 38	, 30));

		// adding info tab component to its panels
		info1.add(info1Lbl);
		info2.add(info2Lbl);
		info3.add(info3Lbl);
		info4.add(info4Lbl);
		info5.add(info5Lbl);
		info6.add(info6Lbl);
		info7.add(info7Lbl);
		info8.add(info8Lbl);
		info9.add(info9Lbl);
		info10.add(info10Lbl);
		info11.add(info11Lbl);
		info12.add(tyLbl);
		info13.add(infoCreditLbl);
		info14.add(infoImgLbl);
		info.add(info1);
		info.add(info2);
		info.add(info3);
		info.add(info4);
		info.add(info5);
		info.add(info6);
		info.add(info7);
		info.add(info8);
		info.add(info9);
		info.add(info10);
		info.add(info11);
		info.add(info12);
		info.add(info13);
		info.add(info14);

		//creating tabbedpane and adding the panels to it and styling the tabs
		JTabbedPane tabs = new JTabbedPane();
		tabs.add("Teams", teams);
		tabs.add("Matches", matches);
		tabs.add("Shop", shop);
		tabs.add("Info", info);
		tabs.setBackgroundAt(0, Color.ORANGE);
		tabs.setBackgroundAt(1, Color.ORANGE);
		tabs.setBackgroundAt(2, Color.ORANGE);
		tabs.setBackgroundAt(3, Color.ORANGE);

		//adding the tabs to the jframe
		add(tabs);
	} // end of createComponents
} // end of TeamFrame