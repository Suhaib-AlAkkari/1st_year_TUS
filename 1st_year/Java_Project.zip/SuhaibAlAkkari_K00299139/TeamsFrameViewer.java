// Name: Suhaib Al Akkari
// Date: 28/04/2024
// TeamsFrameViewer

import javax.swing.*;

public class TeamsFrameViewer
{
	public static void main (String[] args)
	{
		JFrame frame = new TeamsFrame(); // creating a new TeamsFrame object
		frame.setTitle("CS2");
		frame.setResizable(false);	// disabling the ability to resize the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}