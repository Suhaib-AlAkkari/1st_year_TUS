// Name: Suhaib Al Akkari
// Date: 28/04/2024
// Teams

import java.util.*;

public class Teams
{
	// instance variables
	private ArrayList<String> teams = new ArrayList<>(); // for teams names
	private ArrayList<Integer> playersNum = new ArrayList<>(); // for the number of players

	// default constructor
	public Teams()
	{
		teams.add("Spirit");
		teams.add("Faze");
		teams.add("G2");
		teams.add("Virtus Pro");
		teams.add("Navi");
		playersNum.add(5);
		playersNum.add(5);
		playersNum.add(5);
		playersNum.add(5);
		playersNum.add(6);
	}

	// parameterized constructor
	public Teams(String t, int p)
	{
		teams.add(t);
		playersNum.add(p);
	}

	// set methods
	public void setTeams(int i, String t)
	{
		teams.set(i, t);
	}
	public void setPlayersNum(int i, int n)
	{
		playersNum.set(i, n);
	}

	// get methods
	public String getTeams(int i)
	{
		return teams.get(i);
	}
	public int getPlayersNum(int i)
	{
		return playersNum.get(i);
	}

	// add methods
	public void addTeam(String t)
	{
		teams.add(t);
	}
	public void addPlayersNum(int i)
	{
		playersNum.add(i);
	}

	// size methods
	public int sizeTeams()
	{
		return teams.size();
	}
	public int sizePlayersNum()
	{
		return playersNum.size();
	}

	// contains methods
	public boolean containsTeams(String t)
	{
		return teams.contains(t);
	}
	public boolean containsPlayersNum(int i)
	{
		return playersNum.contains(i);
	}

	// indexof methods
	public int indexOfTeams(String t)
	{
		return teams.indexOf(t);
	}
	public int indexOfPlayersNum(int i)
	{
		return playersNum.indexOf(i);
	}

	// remove methods
	public void removeTeams(int i)
	{
		teams.remove(i);
	}
	public void removePlayersNum(int i)
	{
		playersNum.remove(i);
	}

	//toString method
	public String toString()
	{
		String output = "";

		for(int i = 0; i < teams.size(); i++)
		{
			output += "Team Name: " + teams.get(i) + " | Number of Players: " + playersNum.get(i) + "\n";
		}

		return output;
	}
}